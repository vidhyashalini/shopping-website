import { Component } from '@angular/core';

@Component({
  selector: 'app-return',
  templateUrl: './return.component.html',
  styleUrl: './return.component.css'
})
export class ReturnComponent {

}
