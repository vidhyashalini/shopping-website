import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';  
import { AppRoutingModule } from './app-routing.module';   
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { NavigationComponent} from './navigation/navigation.component';
import { HomeComponent } from './home/home.component';
import { ReturnComponent } from './return/return.component';
import { ProductsComponent } from './products/products.component';
import { MenComponent } from './men/men.component';
import { WomenComponent } from './women/women.component';
import { KidsComponent } from './kids/kids.component';
import { FeedbackComponent } from './feedback/feedback.component';

const appRoutes: Routes = [   
   { path: 'home', component: HomeComponent },
   { path: 'register', component: RegisterComponent },
   { path: 'feedback', component: FeedbackComponent },
   { path: 'return', component: ReturnComponent },
   { path: 'kids', component: KidsComponent },
   { path: 'men', component: MenComponent },
   { path: 'women', component: WomenComponent }
];
@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    NavigationComponent,
    HomeComponent,
    ReturnComponent,
    ProductsComponent,
    MenComponent,
    WomenComponent,
    KidsComponent,
    FeedbackComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(appRoutes)  
  ],
  providers: [
    provideClientHydration()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }